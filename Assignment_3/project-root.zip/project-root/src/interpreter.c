//#define DEBUG 1

#ifdef DEBUG
#   define debug(...) fprintf(stderr, __VA_ARGS__)
#else
#   define debug(...)
// NDEBUG disables asserts
#   define NDEBUG
#endif

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>
#include <ctype.h>              // tolower, isdigit
#include <dirent.h>             // scandir
#include <unistd.h>             // chdir
#include <sys/stat.h>           // mkdir
// for run:
#include <sys/types.h>          // pid_t
#include <sys/wait.h>           // waitpid

#include "shellmemory.h"
#include "shell.h"
#include "readyqueue.h"
#include "scheduler.h"
#include "policy.h"

int badcommand() {
    printf("Unknown Command\n");
    return 1;
}

// For source command only
int badcommandFileDoesNotExist() {
    printf("Bad command: File not found\n");
    return 3;
}

int badcommandMkdir() {
    printf("Bad command: my_mkdir\n");
    return 4;
}

int badcommandCd() {
    printf("Bad command: my_cd\n");
    return 5;
}

int help();
int quit();
int set(char *var, char *value);
int print(char *var);
int echo(char *tok);
int ls();
int my_mkdir(char *name);
int touch(char *path);
int cd(char *path);
int source(char *script);
int run(char *args[], int args_size);
int exec(char* args[], int args_size, int mt_flag, int batch_flag);
int badcommandFileDoesNotExist();

// Interpret commands and their arguments
int interpreter(char *command_args[], int args_size) {
    int i;

    // these bits of debug output were very helpful for debugging
    // the changes we made to the parser!
    debug("#args: %d\n", args_size);
#ifdef DEBUG
    for (size_t i = 0; i < args_size; ++i) {
        debug("  %ld: %s\n", i, command_args[i]);
    }
#endif

    if (args_size < 1) {
        // This shouldn't be possible but we are defensive programmers.
        fprintf(stderr, "interpreter called with no words?\n");
        exit(1);
    }

    for (i = 0; i < args_size; i++) {   // terminate args at newlines
        command_args[i][strcspn(command_args[i], "\r\n")] = 0;
    }

    if (strcmp(command_args[0], "help") == 0) {
        //help
        if (args_size != 1)
            return badcommand();
        return help();

    } else if (strcmp(command_args[0], "quit") == 0) {
        //quit
        if (args_size != 1)
            return badcommand();
        return quit();

    } else if (strcmp(command_args[0], "set") == 0) {
        //set
        if (args_size != 3)
            return badcommand();
        return set(command_args[1], command_args[2]);

    } else if (strcmp(command_args[0], "print") == 0) {
        if (args_size != 2)
            return badcommand();
        return print(command_args[1]);

    } else if (strcmp(command_args[0], "echo") == 0) {
        if (args_size != 2)
            return badcommand();
        return echo(command_args[1]);

    } else if (strcmp(command_args[0], "my_ls") == 0) {
        if (args_size != 1)
            return badcommand();
        return ls();

    } else if (strcmp(command_args[0], "my_mkdir") == 0) {
        if (args_size != 2)
            return badcommand();
        return my_mkdir(command_args[1]);

    } else if (strcmp(command_args[0], "my_touch") == 0) {
        if (args_size != 2)
            return badcommand();
        return touch(command_args[1]);

    } else if (strcmp(command_args[0], "my_cd") == 0) {
        if (args_size != 2)
            return badcommand();
        return cd(command_args[1]);

    } else if (strcmp(command_args[0], "source") == 0) {
        if (args_size != 2)
            return badcommand();
        return source(command_args[1]);

    } else if (strcmp(command_args[0], "run") == 0) {
        if (args_size < 2)
            return badcommand();
        return run(&command_args[1], args_size - 1);
    } else if (strcmp(command_args[0], "exec") == 0){
        // Check arguments
        if (args_size < 3 || args_size > 7){
            return badcommand();
	    }
        if (command_args == NULL){
            printf("Command_args is null\n");
            return 1;
        }

        // Set up flags to check for optional arguments
        int batch_flag = 0;
        int last = args_size - 1;  // index of last argument

        // Check last argument for MT (multi-threading mode)
        if (strcmp(command_args[last], "MT") == 0) {
            mt_flag = 1;  // set global flag (see scheduler.c)
            last--;  // adjust to then check for batch mode
        }

        // Check last (or second to last) argument for # (batch mode)
        if (strcmp(command_args[last], "#") == 0) {
            batch_flag = 1;
            last--;  // adjust to get index of policy
        }

        // Set up and run the exec command
        // number of arguments to pass to exec: programs + policy
        int exec_argc = last;  // skips # and/or MT if present

        // copy program args + policy
        char *args[10];
        for (int i = 0; i < exec_argc; i++) {
            args[i] = command_args[i + 1];  // skip "exec"
        }	
        args[exec_argc] = NULL;  // NULL-terminate the args for exec

        return exec(args, exec_argc, mt_flag, batch_flag);  // run exec
    }
    else {
	    return badcommand();
    }
}

int help() {

    // note the literal tab characters here for alignment
    char help_string[] = "COMMAND			DESCRIPTION\n \
help			Displays all the commands\n \
quit			Exits / terminates the shell with “Bye!”\n \
set VAR STRING		Assigns a value to shell memory\n \
print VAR		Displays the STRING assigned to VAR\n \
source SCRIPT.TXT		Executes the file SCRIPT.TXT\n ";
    printf("%s\n", help_string);
    return 0;
}

int quit() {
    printf("Bye!\n");

    // quit for MT -- accessed by the threads! (exiting from main only)
    if (mt_flag) {
        quit_requested = true;  // doesn't need lock since we only care about setting it true
        return 0;
    }
    // single-threaded quit
    else {
        exit(0);  // exit directly from here since no threads to worry about
    }
}

int set(char *var, char *value) {
    mem_set_value(var, value);
    return 0;
}

int print(char *var) {
    char *value = mem_get_value(var);
    if (value) {
        printf("%s\n", value);
        free(value);
    } else {
        printf("Variable does not exist\n");
    }
    return 0;
}

int echo(char *tok) {
    int must_free = 0;
    // is it a var?
    if (tok[0] == '$') {
        tok++;                  // advance pointer, so that tok is now the stuff after '$'
        tok = mem_get_value(tok);
        if (tok == NULL) {
            tok = "";           // must use empty string, can't pass NULL to printf
        } else {
            must_free = 1;
        }
    }

    printf("%s\n", tok);

    // memory management technically optional for this assignment
    if (must_free) free(tok);

    return 0;
}

// We can hide dotfiles in ls using either the filter operand to scandir,
// or by checking the first character ourselves when we go to print
// the names. That would work, and is less code, but this is more robust.
// And this is also better since it won't allocate extra dirents.
int ls_filter(const struct dirent *d) {
    if (d->d_name[0] == '.') return 0;
    return 1;
}

int ls_compare_char(char a, char b) {
    // assumption: a,b are both either digits or letters.
    // If this is not true, the characters will be effectively compared
    // as ASCII when we do the lower_a - lower_b fallback.

    // if both are digits, compare them
    if (isdigit(a) && isdigit(b)) {
        return a - b;
    }
    // if only a is a digit, then b isn't, so a wins.
    if (isdigit(a)) {
        return -1;
    }

    // lowercase both letters so we can compare their alphabetic position.
    char lower_a = tolower(a), lower_b = tolower(b);
    if (lower_a == lower_b) {
        // a and b are the same letter, possibly in different cases.
        // If they are really the same letter, this returns 0.
        // Otherwise, it's negative if A was capital,
        // and positive if B is capital.
        return a - b;
    }

    // Otherwise, compare their alphabetic position by comparing
    // them at a known case.
    return lower_a - lower_b;
}

int ls_compare_str(const char *a, const char *b) {
    // a simple strcmp implementation that uses ls_compare_char.
    // We only check if *a is zero, since if *b is zero earlier,
    // it would've been unequal to *a at that time and we would return.
    // If *b is zero at the same point or later than *a, we'll exit the
    // loop and return the correct value with the last comparison.

    while (*a != '\0') {
        int d = ls_compare_char(*a, *b);
        if (d != 0) return d;
        a++, b++;
    }
    return ls_compare_char(*a, *b);
}

int ls_compare(const struct dirent **a, const struct dirent **b) {
    return ls_compare_str((*a)->d_name, (*b)->d_name);
}

int ls() {
    // straight out of the man page examples for scandir
    // alphasort uses strcoll instead of strcmp,
    // so we have to implement our own comparator to match the ls spec.
    // Note that the test cases weren't very picky about the specified order,
    // so if you just used alphasort with scandir, you should have passed.
    // This was intentional on our part.
    struct dirent **namelist;
    int n;

    n = scandir(".", &namelist, NULL, ls_compare);
    if (n == -1) {
        // something is catastrophically wrong, just give up.
        perror("my_ls couldn't scan the directory");
        return 0;
    }

    for (size_t i = 0; i < n; ++i) {
        printf("%s\n", namelist[i]->d_name);
        free(namelist[i]);
    }
    free(namelist);

    return 0;
}

int str_isalphanum(char *name) {
    for (char c = *name; c != '\0'; c = *++name) {
        if (!(isdigit(c) || isalpha(c))) return 0;
    }
    return 1;
}

int my_mkdir(char *name) {
    int must_free = 0;

    debug("my_mkdir: ->%s<-\n", name);

    if (name[0] == '$') {
        ++name;
        // lookup name
        name = mem_get_value(name);
        debug("  lookup: %s\n", name ? name : "(NULL)");
        if (name) {
            // name exists, should free whatever we got
            must_free = 1;
        }
    }
    if (!name || !str_isalphanum(name)) {
        // either name doesn't exist, or isn't valid, error.
        if (must_free) free(name);
        return badcommandMkdir();
    }
    // at this point name is definitely OK

    // 0777 means "777 in octal," aka 511. This value means
    // "give the new folder all permissions that we can."
    int result = mkdir(name, 0777);

    if (result) {
        // description doesn't specify what to do in this case,
        // (including if the directory already exists)
        // so we just give an error message on stderr and ignore it.
        perror("Something went wrong in my_mkdir");
    }

    if (must_free) free(name);
    return 0;
}

int touch(char *path) {
    // we're told we can assume this.
    assert(str_isalphanum(path));
    // if things go wrong, just ignore it.
    FILE *f = fopen(path, "a");
    fclose(f);
    return 0;
}

int cd(char *path) {
    // we're told we can assume this.
    assert(str_isalphanum(path));

    int result = chdir(path);
    if (result) {
        // chdir can fail for several reasons, but the only one we need
        // to handle here for the spec is the ENOENT reason,
        // aka Error NO ENTry -- the directory doesn't exist.
        // Since that's the only one we have to handle, we'll just assume
        // that that's what happened.
        // Alternatively, you can check if the directory exists
        // explicitly first using `stat`. However it is often better to
        // simply try to use a filesystem resource and then recover when
        // you can't, rather than trying to validate first. If you validate
        // first while two users are on the system, there's a race condition!
        return badcommandCd();
    }
    return 0;
}


int source(char *script) {
    // Initialize arrays
    int program_length;
    int total_pages;
    int err_code;

    // Get program length and number of pages
    if ((err_code = compute_program_length(script, &program_length, &total_pages)) != 0) {
        printf("Error loading program %s: file doesn't exist\n", script);
        return err_code;  // stop if a program doesn't exist or memory is full
    }

    // Initialize page table based on how many pages are needed
    int *page_table = malloc(sizeof(int) * total_pages);
	for (int i = 0; i < total_pages ; i++) {page_table[i] = -1;}

    // Load script into program storage
    if (load_init(script, page_table, total_pages) != 0) {
        return badcommandFileDoesNotExist();
    }

    // Create PCB for new program and add to ready-queue
    PCB *pcb = create_pcb(script, program_length, page_table);  // create PCB with page table
    SchedulerContext* ctx = get_scheduler_context("RR");
    enqueue_tail(pcb);

    return scheduler_single(ctx);
}


int run(char *args[], int arg_size) {
    // copy the args into a new NULL-terminated array.
    char **adj_args = calloc(arg_size + 1, sizeof(char *));
    for (int i = 0; i < arg_size; ++i) {
        adj_args[i] = args[i];
    }

    // always flush output streams before forking.
    fflush(stdout);
    // attempt to fork the shell
    pid_t pid = fork();
    if (pid < 0) {
        // fork failed. Report the error and move on.
        perror("fork() failed");
        return 1;
    } else if (pid == 0) {
        // we are the new child process.
        execvp(adj_args[0], adj_args);
        perror("exec failed");
        // The parent and child are sharing stdin, and according to
        // a part of the glibc documentation that you are **not**
        // expected to know for this course, a shared input handle
        // should be fflushed (if it is needed) or closed
        // (if it is not). Handling this exec error case is not even
        // necessary, but let's do it right.
        // (Failure to do this can result in the parent process
        // reading the remaining input twice in batch mode.)
        fclose(stdin);
        exit(1);
    } else {
        // we are the parent process.
        waitpid(pid, NULL, 0);
    }

    return 0;
}


bool has_duplicate_files(char *files[], int num_files, int dup[]) {
    // check for duplicates in the list of files
    // if files[i] and files[j] are the same, set dup[j] = i, where i is the index of the first occurrence of that file. 
    // Otherwise, dup[j] should be -1.
    bool flag = false;
    for (int i = 0; i < num_files - 1; i++) {
        for (int j = i + 1; j < num_files; j++) {
            if (strcmp(files[i], files[j]) == 0) {
		    dup[j] = i;
		    flag = true;
            }
        }
    }
    return flag;
}


int exec(char *args[], int args_size, int mt_flag, int batch_flag){
	int err_code;
    char* policy;
    int num_programs = args_size - 1;
	policy = args[num_programs];

    // Get context for the scheduler
    SchedulerContext* ctx = get_scheduler_context(policy);
    if (ctx == NULL) return 1;  // invalid policy

    // Allocate space to store program lengths and number of pages needed for each program
	int prog_lengths[num_programs];
    memset(prog_lengths, -1, sizeof(prog_lengths)); //intialize to -1	
    int num_pages_total[num_programs];
    memset(num_pages_total, -1, sizeof(num_pages_total)); //initialize to -1

    // Compute program lengths and number of pages needed for each program
    for (int i = 0; i < num_programs; i++) {
        if ((err_code = compute_program_length(args[i], &prog_lengths[i], &num_pages_total[i])) != 0) {
            printf("Error loading program %s: file doesn't exist\n", args[i]);
            return err_code;  // stop if a program doesn't exist or memory is full
        }
    }

    // Allocate space for page tables
    int* prog_page_tables[num_programs];  // array of page tables (one table per program)
    for (int i = 0; i < num_programs; i++) {
        prog_page_tables[i] = malloc(sizeof(int) * num_pages_total[i]); 
        memset(prog_page_tables[i], -1, sizeof(int) * num_pages_total[i]);  // initialize to -1
    }

    // Check if there are duplicate programs and set a flag for later.
    int duplicates[num_programs];  // duplicates occurences of files will have index of first occurrence, otherwise -1
    for (int i = 0; i < num_programs; i++) {duplicates[i] = -1;} // initialize all entries to -1
    bool duplicate_flag = has_duplicate_files(args, num_programs, duplicates);

    // Load all input programs into memory
    for (int i = 0; i < num_programs; i++){
        // check if program already exists in memory
        int p = duplicates[i];  // -1 if no duplicate, otherwise index of first occurrence of the same file

        if (p != -1 && duplicate_flag){  // if it exists, just copy the table
            prog_page_tables[i] = prog_page_tables[p];  // shared page table!
        } else {  // load program in memory
            if ((err_code = load_init(args[i], prog_page_tables[i], num_pages_total[i])) != 0) {
                printf("Error loading program %s: file doesn't exist\n", args[i]);
                return err_code;  // stop if a program doesn't exist or memory is full
            }
        }
    }

    // Create & enqueue all PCBs (only if all programs loaded successfully)
    for (int i = 0; i < num_programs; i++){
        PCB *pcb = create_pcb(args[i], prog_lengths[i], prog_page_tables[i]);

        if (mt_flag) {
                pthread_mutex_lock(&ready_queue_lock);
                ctx->enqueue_func(pcb);
                pthread_mutex_unlock(&ready_queue_lock);
            } else {
                ctx->enqueue_func(pcb);
            }
    }

    // If # is enabled, load PCB to ready queue at head. -- NOT NEEDED FOR THIS ASSIGNMENT, not updated for paging :(
    // if (batch_flag) {
    //     int program_length;
    //     int *page_table = malloc(sizeof(int) * NUM_FRAMES);
    //     memset(page_table, -1, sizeof(int) * NUM_FRAMES);

    //     int code = load_program_file(stdin, &program_length, page_table);  // prog0 = the rest of the script after the exec line
    //     if (code == 0){
    //         PCB* batch_pcb = create_pcb("batch_program", program_length, page_table);  // we can just reuse the page table from the first program since it's all stored in the same place in memory
    //         if (batch_pcb != NULL){  // put batch program at front of queue
    //             if (mt_flag) {
    //                 pthread_mutex_lock(&ready_queue_lock);
    //                 enqueue_head(batch_pcb);
    //                 pthread_mutex_unlock(&ready_queue_lock);
    //             } else {
    //                 enqueue_head(batch_pcb);
    //             }
    //         }
    //     }
    // }

    // Run the correct scheduler with appropriate context
    if (mt_flag) {
        return scheduler_multi(ctx);  // creates 2 worker threads
    } else {
        return scheduler_single(ctx);
    }

    // free page tables
    for (int i = 0; i < num_programs; i++) {
        free(prog_page_tables[i]);
    }
	return 0;
}



