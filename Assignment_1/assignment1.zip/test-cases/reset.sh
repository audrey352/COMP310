#!/bin/bash
rm -rf test
rm -rf testdir
rm -rf toto
