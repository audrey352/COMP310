#define MAX_USER_INPUT 1000
int parseInput(char inp[]);
extern pthread_t main_thread;
